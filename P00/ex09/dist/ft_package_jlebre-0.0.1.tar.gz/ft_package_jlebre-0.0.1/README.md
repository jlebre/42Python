# ft_package

**ft_package** is a simple Python package for demonstration purposes.

## Installation

You can install the package using:

```sh
pip install ft_package
```